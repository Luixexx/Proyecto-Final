const taskList = document.getElementById("taskList");
const taskForm = document.getElementById("taskForm");
const titleInput = document.getElementById("title");

const API = "http://localhost:3000/api/tasks";

let editMode = false;
let editTaskId = null;

async function loadTasks() {
  const res = await fetch(API);
  const tasks = await res.json();

  taskList.innerHTML = "";
  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.classList.toggle("completed", task.completed);
    li.innerHTML = `
  <span>${task.title}</span>
  <div>
    <button onclick="toggleTask('${task._id}', ${task.completed})">✔</button>
    <button onclick="editTask('${task._id}', '${task.title}')">📝</button>
    <button onclick="deleteTask('${task._id}')">🗑️</button>
  </div>
`;

    taskList.appendChild(li);
  });
}

taskForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = titleInput.value.trim();
  if (!title) return;

  if (editMode) {
    await fetch(`${API}/${editTaskId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
    });
    editMode = false;
    editTaskId = null;
    taskForm.querySelector("button").innerText = "Agregar";
  } else {
    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
    });
  }

  titleInput.value = "";
  loadTasks();
});

function editTask(id, title) {
  titleInput.value = title;
  editTaskId = id;
  editMode = true;
  taskForm.querySelector("button").innerText = "Actualizar";
}

async function deleteTask(id) {
  await fetch(`${API}/${id}`, { method: "DELETE" });
  loadTasks();
}

async function toggleTask(id, currentStatus) {
  await fetch(`${API}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ completed: !currentStatus }),
  });
  loadTasks();
}

loadTasks();

window.onload = () => {
  // Modo oscuro
  const toggleBtn = document.getElementById("toggleTheme");
  toggleBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    toggleBtn.innerText = document.body.classList.contains("dark")
      ? "☀️ Modo Claro"
      : "🌙 Modo Oscuro";
  });

  // Cargar tareas al iniciar
  loadTasks();
};
