import os
import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# URL base del frontend
URL = "http://localhost:3000/"

# Crear carpeta screenshots si no existe
screenshots_dir = os.path.join(os.path.dirname(__file__), "screenshots")
os.makedirs(screenshots_dir, exist_ok=True)

# Fixture del navegador
@pytest.fixture
def driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = webdriver.Chrome(options=options)
    yield driver
    driver.quit()

# Función para esperar un elemento
def esperar_elemento(driver, by, value, timeout=10):
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, value))
    )

# 1. Crear tarea
def test_crear_tarea(driver):
    driver.get(URL)
    esperar_elemento(driver, By.ID, "title")
    input_field = driver.find_element(By.ID, "title")
    input_field.send_keys("Tarea Selenium Completa")
    input_field.send_keys(Keys.RETURN)
    time.sleep(1)
    file_name = os.path.join(screenshots_dir, "test_crear_tarea.png")
    driver.save_screenshot(file_name)
    tareas = driver.find_elements(By.TAG_NAME, "li")
    assert any("Tarea Selenium Completa" in t.text for t in tareas)

# 2. Completar tarea
def test_completar_tarea(driver):
    driver.get(URL)
    esperar_elemento(driver, By.ID, "title")
    input_field = driver.find_element(By.ID, "title")
    input_field.send_keys("Tarea para completar")
    input_field.send_keys(Keys.RETURN)
    time.sleep(1)
    tareas = driver.find_elements(By.TAG_NAME, "li")
    tarea = tareas[-1]
    completar_btn = tarea.find_elements(By.TAG_NAME, "button")[0]
    completar_btn.click()
    time.sleep(1)
    file_name = os.path.join(screenshots_dir, "test_completar_tarea.png")
    driver.save_screenshot(file_name)
    tareas_actualizadas = driver.find_elements(By.TAG_NAME, "li")
    tarea_actualizada = tareas_actualizadas[-1]
    assert "completed" in tarea_actualizada.get_attribute("class")

# 3. Editar tarea
def test_editar_tarea(driver):
    driver.get(URL)
    esperar_elemento(driver, By.ID, "title")
    input_field = driver.find_element(By.ID, "title")
    input_field.send_keys("Tarea editable")
    input_field.send_keys(Keys.RETURN)
    time.sleep(1)
    tarea = driver.find_elements(By.TAG_NAME, "li")[-1]
    editar_btn = tarea.find_elements(By.TAG_NAME, "button")[1]
    editar_btn.click()
    time.sleep(1)
    input_field = driver.find_element(By.ID, "title")
    input_field.clear()
    input_field.send_keys("Tarea editada con éxito")
    input_field.send_keys(Keys.RETURN)
    time.sleep(1)
    file_name = os.path.join(screenshots_dir, "test_editar_tarea.png")
    driver.save_screenshot(file_name)
    tareas = driver.find_elements(By.TAG_NAME, "li")
    assert any("Tarea editada con éxito" in t.text for t in tareas)

# 4. Eliminar tarea
def test_eliminar_tarea(driver):
    driver.get(URL)
    esperar_elemento(driver, By.ID, "title")
    input_field = driver.find_element(By.ID, "title")
    input_field.send_keys("Tarea a eliminar")
    input_field.send_keys(Keys.RETURN)
    time.sleep(1)
    tareas = driver.find_elements(By.TAG_NAME, "li")
    tarea = tareas[-1]
    eliminar_btn = tarea.find_elements(By.TAG_NAME, "button")[2]
    eliminar_btn.click()
    time.sleep(1)
    file_name = os.path.join(screenshots_dir, "test_eliminar_tarea.png")
    driver.save_screenshot(file_name)
    tareas_actualizadas = driver.find_elements(By.TAG_NAME, "li")
    assert not any("Tarea a eliminar" in t.text for t in tareas_actualizadas)

# 5. Modo oscuro
def test_modo_oscuro(driver):
    driver.get(URL)
    esperar_elemento(driver, By.ID, "toggleTheme")
    btn_tema = driver.find_element(By.ID, "toggleTheme")
    btn_tema.click()
    time.sleep(1)
    file_name = os.path.join(screenshots_dir, "test_modo_oscuro.png")
    driver.save_screenshot(file_name)
    body = driver.find_element(By.TAG_NAME, "body")
    assert "dark" in body.get_attribute("class")

